#!/bin/sh
cd metrics-script
python3 main.py
